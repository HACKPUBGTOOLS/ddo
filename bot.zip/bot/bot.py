#863107027446136852
#ODYzMTA3MDI3NDQ2MTM2ODUy.YOiFDw.gVVH_aqPqHTZaCfQFeDEyLAkjSw
#3694132978

import discord

client = discord.Client()

@client.event
async def on_ready():
	print(f"Logged in as {client.usr}")
	
	@client.event
	async def message(message):
		if message.content == "#ตาแก่":
			await message.chanel.send("สวัสดีครับชมรมคนชอบ")
			elif message.content == "#เติมเงิน":
				await message.chanel.send("1วัน=10บาท")
				elif message.content == "#ddosคืออะไร":
					await message.chanel.send("การโจมตีทางcyberที่ส่งคนเข้าเว็บำซต์จำนวนมากจนเว็บดับ")
					elif message.content == "555":
						await message.chanel.send("ตลกอะไรกัน")
					
				
	client.run("ODYzMTA3MDI3NDQ2MTM2ODUy.YOiFDw.gVVH_aqPqHTZaCfQFeDEyLAkjSw")